<?php
// Define the number of images per page
$imagesPerPage = 3;

// Load images from the images/ directory
$directory = 'images/';
$images = array_diff(scandir($directory), array('..', '.')); // Get image files

// Get current page from query string, default to 1 if not set
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;

// Calculate the offset for the current page
$offset = ($page - 1) * $imagesPerPage;

// Slice the array to get the images for the current page
$imagesArray = array_slice($images, $offset, $imagesPerPage);

// Calculate total number of pages
$totalPages = ceil(count($images) / $imagesPerPage);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Photo Album - Images Page <?php echo $page; ?></title>
</head>
<body>
<h1 style="text-align: center; margin-top: 50px;">Simple Photo Album</h1>

    <div class="image-container">
        <!-- Display the main image (1st image in the current page) -->
        <div class="main-image">
            <?php if (isset($imagesArray[0])): ?>
                <img src="<?php echo $directory . $imagesArray[0]; ?>" alt="Main Image">
            <?php endif; ?>
        </div>
        
        <!-- Display two smaller images (2nd and 3rd images in the current page) -->
        <div class="side-images">
            <?php if (isset($imagesArray[1])): ?>
                <img src="<?php echo $directory . $imagesArray[1]; ?>" alt="Small Image 1">
            <?php endif; ?>
            <?php if (isset($imagesArray[2])): ?>
                <img src="<?php echo $directory . $imagesArray[2]; ?>" alt="Small Image 2">
            <?php endif; ?>
        </div>
    </div>

    <!-- Pagination Links with Next and Previous Buttons -->
    <div class="pagination">
        <?php if ($page > 1): ?>
            <!-- Show "Previous" button when not on the first page -->
            <a class="prev-button" href="?page=<?php echo $page - 1; ?>">&laquo; Previous</a>
        <?php endif; ?>

        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <a href="?page=<?php echo $i; ?>" 
               class="<?php echo $i == $page ? 'active' : ''; ?>">
               <?php echo $i; ?>
            </a>
        <?php endfor; ?>

        <?php if ($page < $totalPages): ?>
            <!-- Show "Next" button when not on the last page -->
            <a class="next-button" href="?page=<?php echo $page + 1; ?>">Next &raquo;</a>
        <?php endif; ?>
    </div>

</body>
</html>
