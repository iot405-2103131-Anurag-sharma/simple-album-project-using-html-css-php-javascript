document.addEventListener("DOMContentLoaded", function () {
    const prevButton = document.querySelector('.prev-button');
    const nextButton = document.querySelector('.next-button');
    const imageContainer = document.querySelector('.image-container');

    let currentPage = parseInt(new URLSearchParams(window.location.search).get('page')) || 1;

    // Handle "Next" button click
    if (nextButton) {
        nextButton.addEventListener("click", function (e) {
            e.preventDefault();
            slideToNextPage();
            // Redirect to next page after animation
            setTimeout(() => {
                window.location.href = nextButton.getAttribute('href');
            }, 500); // Wait for animation to finish
        });
    }

    // Handle "Previous" button click
    if (prevButton) {
        prevButton.addEventListener("click", function (e) {
            e.preventDefault();
            slideToPrevPage();
            // Redirect to previous page after animation
            setTimeout(() => {
                window.location.href = prevButton.getAttribute('href');
            }, 500); // Wait for animation to finish
        });
    }

    // Function to trigger the slide effect to the next page
    function slideToNextPage() {
        imageContainer.classList.add('slide-left');
    }

    // Function to trigger the slide effect to the previous page
    function slideToPrevPage() {
        imageContainer.classList.add('slide-right');
    }
});
